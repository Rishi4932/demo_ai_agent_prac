
import re
from dataclasses import dataclass
from typing import Dict, Any


from execution.mouse_keyboard import MouseKeyboardController
from execution.windows_uia import WindowsUIAutomation


from safety.permissions import ActionPermissionChecker
from safety.confirmation import ConfirmationManager


@dataclass
class ActionResult:
    success: bool
    action: str
    message: str
    data: Any = None
    executor: str = ""


class ActionRouter:

    def __init__(
        self,
        mouse_keyboard=None,
        windows_uia=None,
        browser=None,
        permission_checker=None,
    ):
        self.mouse_keyboard = (
            mouse_keyboard
            or MouseKeyboardController()
        )

        self.windows_uia = (
            windows_uia
            or WindowsUIAutomation()
        )

        self.browser = browser
        self.permission_checker = (
            permission_checker
            or ActionPermissionChecker()
        )

        self.confirmation_manager = (
            ConfirmationManager()
        )

    # ============================================================
    # PUBLIC EXECUTION API
    # ============================================================

    def execute(
        self,
        action: Dict[str, Any],
    ) -> ActionResult:
        """
        Validate and execute an action.

        Safe actions are executed immediately.
        Blocked actions are rejected.
        Risky actions are not executed until
        the user confirms them.
        """

        if not isinstance(action, dict):
            return ActionResult(
                success=False,
                action="unknown",
                message="Action must be a dictionary.",
                executor="safety",
            )

        action_type = action.get(
            "action",
            "",
        )

        # --------------------------------------------------------
        # Safety validation
        # --------------------------------------------------------

        try:
            permission = (
                self.permission_checker.validate(
                    action
                )
            )

        except Exception as error:
            return ActionResult(
                success=False,
                action=action_type,
                message=(
                    f"Permission check failed: {error}"
                ),
                data={
                    "requires_confirmation": False,
                },
                executor="safety",
            )

        # --------------------------------------------------------
        # Blocked action
        # --------------------------------------------------------

        if not permission.get(
            "allowed",
            False,
        ):
            return ActionResult(
                success=False,
                action=action_type,
                message=permission.get(
                    "reason",
                    "Action blocked by safety policy.",
                ),
                data={
                    "requires_confirmation": False,
                },
                executor="safety",
            )

        # --------------------------------------------------------
        # Risky action
        # --------------------------------------------------------

        if permission.get(
            "requires_confirmation",
            False,
        ):
            return ActionResult(
                success=False,
                action=action_type,
                message=permission.get(
                    "reason",
                    "Action requires user confirmation.",
                ),
                data={
                    "requires_confirmation": True,
                },
                executor="safety",
            )

        # --------------------------------------------------------
        # Safe action
        # --------------------------------------------------------

        try:
            return self._dispatch_action(
                action
            )

        except Exception as error:
            return ActionResult(
                success=False,
                action=action_type,
                message=str(error),
                data={
                    "requires_confirmation": False,
                },
                executor="router",
            )

    # ============================================================
    # CONFIRMATION
    # ============================================================

    def request_confirmation(
        self,
        action: Dict[str, Any],
    ) -> Dict[str, Any]:

        if not isinstance(action, dict):
            return {
                "success": False,
                "token": None,
                "action": action,
                "reason": "Action must be a dictionary.",
            }

        action_type = action.get("action")

        if not action_type:
            return {
                "success": False,
                "token": None,
                "action": action,
                "reason": "Action type is missing.",
            }

        # --------------------------------------------------------
        # Validate action
        # --------------------------------------------------------

        try:
            permission = (
                self.permission_checker.validate(
                    action
                )
            )

        except Exception as error:
            return {
                "success": False,
                "token": None,
                "action": action,
                "reason": (
                    f"Permission check failed: {error}"
                ),
            }

        allowed = permission.get(
            "allowed",
            False,
        )

        requires_confirmation = permission.get(
            "requires_confirmation",
            False,
        )

        reason = permission.get(
            "reason",
            "Action was rejected by the safety layer.",
        )

        # --------------------------------------------------------
        # Blocked action
        # --------------------------------------------------------

        if not allowed:
            return {
                "success": False,
                "token": None,
                "action": action,
                "reason": reason,
            }

        # --------------------------------------------------------
        # Safe action
        # --------------------------------------------------------

        if not requires_confirmation:
            return {
                "success": False,
                "token": None,
                "action": action,
                "reason": (
                    f"Action '{action_type}' "
                    "does not require confirmation."
                ),
            }

        # --------------------------------------------------------
        # Create confirmation request
        # --------------------------------------------------------

        try:
            request = (
                self.confirmation_manager.create_request(
                    action
                )
            )

        except Exception as error:
            return {
                "success": False,
                "token": None,
                "action": action,
                "reason": (
                    "Could not create confirmation request: "
                    f"{error}"
                ),
            }

        return {
            "success": True,
            "token": request.token,
            "action": action,
            "reason": (
                "Confirmation request created."
            ),
        }

    def confirm_action(
        self,
        token,
        action: Dict[str, Any],
    ) -> Dict[str, Any]:

        if not isinstance(action, dict):
            return {
                "success": False,
                "reason": "Action must be a dictionary.",
            }

        try:
            return self.confirmation_manager.confirm(
                token=token,
                action=action,
            )

        except Exception as error:
            return {
                "success": False,
                "reason": f"Confirmation failed: {error}",
            }

    def execute_confirmed(
        self,
        token,
        action: Dict[str, Any],
    ) -> ActionResult:

        if not isinstance(action, dict):
            return ActionResult(
                success=False,
                action="unknown",
                message="Action must be a dictionary.",
                executor="safety",
            )

        action_type = action.get(
            "action"
        )

        if not action_type:
            return ActionResult(
                success=False,
                action="unknown",
                message="Action type is missing.",
                executor="safety",
            )

        # --------------------------------------------------------
        # Revalidate permission
        # --------------------------------------------------------

        try:
            permission = (
                self.permission_checker.validate(
                    action
                )
            )

        except Exception as error:
            return ActionResult(
                success=False,
                action=action_type,
                message=(
                    f"Permission check failed: {error}"
                ),
                executor="safety",
            )

        allowed = permission.get(
            "allowed",
            False,
        )

        requires_confirmation = permission.get(
            "requires_confirmation",
            False,
        )

        reason = permission.get(
            "reason",
            "Action was rejected by the safety layer.",
        )

        # --------------------------------------------------------
        # Blocked action
        # --------------------------------------------------------

        if not allowed:
            return ActionResult(
                success=False,
                action=action_type,
                message=reason,
                executor="safety",
            )

        # --------------------------------------------------------
        # Safe action
        # --------------------------------------------------------

        if not requires_confirmation:
            return self._dispatch_action(
                action
            )

        # --------------------------------------------------------
        # Consume confirmation token
        # --------------------------------------------------------

        try:
            consumed = (
                self.confirmation_manager.consume(
                    token=token,
                    action=action,
                )
            )

        except Exception as error:
            return ActionResult(
                success=False,
                action=action_type,
                message=(
                    f"Confirmation failed: {error}"
                ),
                executor="safety",
            )

        if not consumed.get(
            "success",
            False,
        ):
            return ActionResult(
                success=False,
                action=action_type,
                message=consumed.get(
                    "reason",
                    "Confirmation could not be consumed.",
                ),
                executor="safety",
            )

        # --------------------------------------------------------
        # Execute exactly once
        # --------------------------------------------------------

        return self._dispatch_action(
            action
        )

    # ============================================================
    # RAW UIA WINDOW RESOLUTION
    # ============================================================

    def _find_raw_window(
        self,
        window_title=None,
        window_title_re=None,
    ):
        """
        Resolve a fresh raw UIA window.

        Supports:

        1. Exact title matching.
        2. Regular-expression title matching.
        """

        if not window_title and not window_title_re:
            raise ValueError(
                "window_title or window_title_re is required."
            )

        # --------------------------------------------------------
        # Exact title
        # --------------------------------------------------------

        if window_title:
            return self.windows_uia.find_raw_window(
                title=window_title
            )

        # --------------------------------------------------------
        # Regex title
        # --------------------------------------------------------

        pattern = re.compile(
            window_title_re
        )

        windows = (
            self.windows_uia.raw_top_level_windows()
        )

        for window in windows:

            try:
                window_name = window.name

                if not window_name:
                    continue

                if pattern.search(
                    window_name
                ):
                    return window

            except Exception:
                continue

        return None

    # ============================================================
    # INTERNAL DISPATCH
    # ============================================================

    def _dispatch_action(
        self,
        action: Dict[str, Any],
    ) -> ActionResult:

        action_type = action.get(
            "action"
        )

        if not action_type:
            return ActionResult(
                success=False,
                action="unknown",
                message="Action type is missing.",
            )

        try:

            # ====================================================
            # Mouse / Keyboard
            # ====================================================

            if action_type == "move":

                self.mouse_keyboard.move(
                    action["x"],
                    action["y"],
                    action.get("duration"),
                )

                return ActionResult(
                    success=True,
                    action=action_type,
                    message="Mouse moved successfully.",
                    executor="mouse_keyboard",
                )

            if action_type == "click":

                self.mouse_keyboard.click(
                    action["x"],
                    action["y"],
                    action.get(
                        "button",
                        "left",
                    ),
                )

                return ActionResult(
                    success=True,
                    action=action_type,
                    message="Mouse clicked successfully.",
                    executor="mouse_keyboard",
                )

            if action_type == "double_click":

                self.mouse_keyboard.double_click(
                    action["x"],
                    action["y"],
                )

                return ActionResult(
                    success=True,
                    action=action_type,
                    message="Double click completed.",
                    executor="mouse_keyboard",
                )

            if action_type == "right_click":

                self.mouse_keyboard.right_click(
                    action["x"],
                    action["y"],
                )

                return ActionResult(
                    success=True,
                    action=action_type,
                    message="Right click completed.",
                    executor="mouse_keyboard",
                )

            if action_type == "type":

                self.mouse_keyboard.type_text(
                    action["text"],
                    action.get(
                        "interval",
                        0.03,
                    ),
                )

                return ActionResult(
                    success=True,
                    action=action_type,
                    message="Text typed successfully.",
                    executor="mouse_keyboard",
                )

            if action_type == "press":

                self.mouse_keyboard.press(
                    action["key"]
                )

                return ActionResult(
                    success=True,
                    action=action_type,
                    message="Key pressed successfully.",
                    executor="mouse_keyboard",
                )

            if action_type == "hotkey":

                self.mouse_keyboard.hotkey(
                    *action["keys"]
                )

                return ActionResult(
                    success=True,
                    action=action_type,
                    message="Hotkey executed successfully.",
                    executor="mouse_keyboard",
                )

            if action_type == "scroll":

                self.mouse_keyboard.scroll(
                    action["amount"]
                )

                return ActionResult(
                    success=True,
                    action=action_type,
                    message="Scroll completed.",
                    executor="mouse_keyboard",
                )

            if action_type == "wait":

                self.mouse_keyboard.wait(
                    action["seconds"]
                )

                return ActionResult(
                    success=True,
                    action=action_type,
                    message="Wait completed.",
                    executor="system",
                )

            # ====================================================
            # Screenshot
            # ====================================================

            if action_type == "screenshot":

                path = action.get(
                    "path",
                    "data/screenshots/action_router.png",
                )

                self.mouse_keyboard.screenshot(
                    path
                )

                return ActionResult(
                    success=True,
                    action=action_type,
                    message="Screenshot captured.",
                    data={
                        "path": path
                    },
                    executor="perception",
                )

            # ====================================================
            # Windows UI Automation
            # ====================================================

            if action_type == "open_application":

                # The agent currently sends:
                #
                # {
                #     "action": "open_application",
                #     "application": "notepad.exe"
                # }
                #
                # Older code may use:
                #
                # {
                #     "action": "open_application",
                #     "executable": "notepad.exe"
                # }
                #
                # Support both formats.

                executable = action.get(
                    "application",
                    action.get("executable"),
                )

                if not executable:
                    return ActionResult(
                        success=False,
                        action=action_type,
                        message=(
                            "Application/executable is required "
                            "for open_application."
                        ),
                        executor="windows_uia",
                    )

                application = (
                    self.windows_uia.open_application(
                        executable
                    )
                )

                return ActionResult(
                    success=True,
                    action=action_type,
                    message="Application opened successfully.",
                    data={
                        "application": str(application)
                    },
                    executor="windows_uia",
                )

            if action_type == "inspect_window":

                window = self.windows_uia.find_window(
                    title=action.get(
                        "window_title"
                    ),
                    title_re=action.get(
                        "window_title_re"
                    ),
                )

                self.windows_uia.print_window_controls(
                    window,
                    depth=action.get(
                        "depth",
                        3,
                    ),
                )

                return ActionResult(
                    success=True,
                    action=action_type,
                    message="Window inspected successfully.",
                    executor="windows_uia",
                )

            if action_type == "click_control":

                window = self.windows_uia.find_window(
                    title=action.get(
                        "window_title"
                    ),
                    title_re=action.get(
                        "window_title_re"
                    ),
                )

                self.windows_uia.click_control(
                    window=window,
                    title=action.get(
                        "control_title"
                    ),
                    control_type=action.get(
                        "control_type"
                    ),
                    auto_id=action.get(
                        "auto_id"
                    ),
                    class_name=action.get(
                        "class_name"
                    ),
                )

                return ActionResult(
                    success=True,
                    action=action_type,
                    message="Windows UI control clicked.",
                    executor="windows_uia",
                )

            if action_type == "type_into_control":

                window = self.windows_uia.find_window(
                    title=action.get(
                        "window_title"
                    ),
                    title_re=action.get(
                        "window_title_re"
                    ),
                )

                self.windows_uia.type_into_control(
                    window=window,
                    text=action["text"],
                    title=action.get(
                        "control_title"
                    ),
                    control_type=action.get(
                        "control_type"
                    ),
                    auto_id=action.get(
                        "auto_id"
                    ),
                    class_name=action.get(
                        "class_name"
                    ),
                )

                return ActionResult(
                    success=True,
                    action=action_type,
                    message=(
                        "Text entered into "
                        "Windows UI control."
                    ),
                    executor="windows_uia",
                )

            if action_type == "get_control_text":

                window = self.windows_uia.find_window(
                    title=action.get(
                        "window_title"
                    ),
                    title_re=action.get(
                        "window_title_re"
                    ),
                )

                text = self.windows_uia.get_control_text(
                    window=window,
                    title=action.get(
                        "control_title"
                    ),
                    control_type=action.get(
                        "control_type"
                    ),
                    auto_id=action.get(
                        "auto_id"
                    ),
                    class_name=action.get(
                        "class_name"
                    ),
                )

                return ActionResult(
                    success=True,
                    action=action_type,
                    message="Control text retrieved.",
                    data={
                        "text": text
                    },
                    executor="windows_uia",
                )

            # ====================================================
            # Fresh Raw UIA - CLICK
            # ====================================================

            if action_type == "uia_click_control":

                window_title = action.get(
                    "window_title"
                )

                window_title_re = action.get(
                    "window_title_re"
                )

                if not window_title and not window_title_re:
                    return ActionResult(
                        success=False,
                        action=action_type,
                        message=(
                            "window_title or "
                            "window_title_re is required "
                            "for uia_click_control."
                        ),
                        executor="windows_uia",
                    )

                window = self._find_raw_window(
                    window_title=window_title,
                    window_title_re=window_title_re,
                )

                if window is None:
                    identifier = (
                        window_title
                        or window_title_re
                    )

                    return ActionResult(
                        success=False,
                        action=action_type,
                        message=(
                            f"Window '{identifier}' "
                            "could not be found."
                        ),
                        executor="windows_uia_raw",
                    )

                control = (
                    self.windows_uia.click_raw_control(
                        window=window,
                        title=action.get(
                            "control_title"
                        ),
                        control_type=action.get(
                            "control_type"
                        ),
                        auto_id=action.get(
                            "auto_id"
                        ),
                        class_name=action.get(
                            "class_name"
                        ),
                    )
                )

                return ActionResult(
                    success=True,
                    action=action_type,
                    message=(
                        "Native Windows UI control "
                        "clicked using fresh UIA discovery."
                    ),
                    data={
                        "control_name": getattr(
                            control,
                            "name",
                            "",
                        ),
                        "control_type": getattr(
                            control,
                            "control_type",
                            "",
                        ),
                        "automation_id": getattr(
                            control,
                            "automation_id",
                            "",
                        ),
                        "class_name": getattr(
                            control,
                            "class_name",
                            "",
                        ),
                        "window_title": getattr(
                            window,
                            "name",
                            "",
                        ),
                    },
                    executor="windows_uia_raw",
                )

            # ====================================================
            # Fresh Raw UIA - INVOKE
            # ====================================================

            if action_type == "uia_invoke_control":

                window_title = action.get(
                    "window_title"
                )

                window_title_re = action.get(
                    "window_title_re"
                )

                if not window_title and not window_title_re:
                    return ActionResult(
                        success=False,
                        action=action_type,
                        message=(
                            "window_title or "
                            "window_title_re is required "
                            "for uia_invoke_control."
                        ),
                        executor="windows_uia",
                    )

                window = self._find_raw_window(
                    window_title=window_title,
                    window_title_re=window_title_re,
                )

                if window is None:
                    identifier = (
                        window_title
                        or window_title_re
                    )

                    return ActionResult(
                        success=False,
                        action=action_type,
                        message=(
                            f"Window '{identifier}' "
                            "could not be found."
                        ),
                        executor="windows_uia_raw",
                    )

                control = (
                    self.windows_uia.invoke_raw_control(
                        window=window,
                        title=action.get(
                            "control_title"
                        ),
                        control_type=action.get(
                            "control_type"
                        ),
                        auto_id=action.get(
                            "auto_id"
                        ),
                        class_name=action.get(
                            "class_name"
                        ),
                    )
                )

                return ActionResult(
                    success=True,
                    action=action_type,
                    message=(
                        "Native Windows UI control "
                        "invoked using fresh UIA discovery."
                    ),
                    data={
                        "control_name": getattr(
                            control,
                            "name",
                            "",
                        ),
                        "control_type": getattr(
                            control,
                            "control_type",
                            "",
                        ),
                        "automation_id": getattr(
                            control,
                            "automation_id",
                            "",
                        ),
                        "class_name": getattr(
                            control,
                            "class_name",
                            "",
                        ),
                        "window_title": getattr(
                            window,
                            "name",
                            "",
                        ),
                    },
                    executor="windows_uia_raw",
                )

            # ====================================================
            # Fresh Raw UIA - GET TEXT
            # ====================================================

            if action_type == "uia_get_control_text":

                window_title = action.get(
                    "window_title"
                )

                window_title_re = action.get(
                    "window_title_re"
                )

                if not window_title and not window_title_re:
                    return ActionResult(
                        success=False,
                        action=action_type,
                        message=(
                            "window_title or "
                            "window_title_re is required "
                            "for uia_get_control_text."
                        ),
                        executor="windows_uia",
                    )

                window = self._find_raw_window(
                    window_title=window_title,
                    window_title_re=window_title_re,
                )

                if window is None:
                    identifier = (
                        window_title
                        or window_title_re
                    )

                    return ActionResult(
                        success=False,
                        action=action_type,
                        message=(
                            f"Window '{identifier}' "
                            "could not be found."
                        ),
                        executor="windows_uia_raw",
                    )

                text = (
                    self.windows_uia.get_raw_control_text(
                        window=window,
                        title=action.get(
                            "control_title"
                        ),
                        control_type=action.get(
                            "control_type"
                        ),
                        auto_id=action.get(
                            "auto_id"
                        ),
                        class_name=action.get(
                            "class_name"
                        ),
                    )
                )

                return ActionResult(
                    success=True,
                    action=action_type,
                    message=(
                        "Native Windows UI control "
                        "text retrieved using fresh "
                        "UIA discovery."
                    ),
                    data={
                        "text": text,
                        "window_title": getattr(
                            window,
                            "name",
                            "",
                        ),
                    },
                    executor="windows_uia_raw",
                )

            # ====================================================
            # Playwright Browser
            # ====================================================

            if action_type == "browser_start":

                self.browser.start()

                return ActionResult(
                    success=True,
                    action=action_type,
                    message="Browser started successfully.",
                    executor="playwright",
                )

            if action_type == "browser_open_url":

                url = self.browser.open_url(
                    action["url"]
                )

                return ActionResult(
                    success=True,
                    action=action_type,
                    message="URL opened successfully.",
                    data={
                        "url": url
                    },
                    executor="playwright",
                )

            if action_type == "browser_click":

                self.browser.click(
                    action["selector"]
                )

                return ActionResult(
                    success=True,
                    action=action_type,
                    message="Browser element clicked.",
                    executor="playwright",
                )

            if action_type == "browser_fill":

                self.browser.fill(
                    action["selector"],
                    action["text"],
                )

                return ActionResult(
                    success=True,
                    action=action_type,
                    message="Browser field filled.",
                    executor="playwright",
                )

            if action_type == "browser_press":

                self.browser.press(
                    action["selector"],
                    action["key"],
                )

                return ActionResult(
                    success=True,
                    action=action_type,
                    message="Browser key pressed.",
                    executor="playwright",
                )

            if action_type == "browser_get_title":

                title = self.browser.get_title()

                return ActionResult(
                    success=True,
                    action=action_type,
                    message="Browser title retrieved.",
                    data={
                        "title": title
                    },
                    executor="playwright",
                )

            if action_type == "browser_get_url":

                url = self.browser.get_url()

                return ActionResult(
                    success=True,
                    action=action_type,
                    message="Browser URL retrieved.",
                    data={
                        "url": url
                    },
                    executor="playwright",
                )

            if action_type == "browser_get_text":

                selector = action.get(
                    "selector",
                    "body",
                )

                text = self.browser.get_text(
                    selector
                )

                return ActionResult(
                    success=True,
                    action=action_type,
                    message="Browser text retrieved.",
                    data={
                        "text": text
                    },
                    executor="playwright",
                )

            if action_type == "browser_screenshot":

                path = action.get(
                    "path",
                    "data/screenshots/browser_action.png",
                )

                screenshot_path = (
                    self.browser.screenshot(
                        path
                    )
                )

                return ActionResult(
                    success=True,
                    action=action_type,
                    message="Browser screenshot captured.",
                    data={
                        "path": screenshot_path
                    },
                    executor="playwright",
                )

            if action_type == "browser_wait":

                milliseconds = action.get(
                    "milliseconds",
                    1000,
                )

                self.browser.wait(
                    milliseconds
                )

                return ActionResult(
                    success=True,
                    action=action_type,
                    message="Browser wait completed.",
                    executor="playwright",
                )

            if action_type == "browser_state":

                state = self.browser.get_state()

                return ActionResult(
                    success=True,
                    action=action_type,
                    message="Browser state retrieved.",
                    data=state,
                    executor="playwright",
                )

            if action_type == "browser_close":

                self.browser.close()

                return ActionResult(
                    success=True,
                    action=action_type,
                    message="Browser closed successfully.",
                    executor="playwright",
                )

            # ====================================================
            # Unknown action
            # ====================================================

            return ActionResult(
                success=False,
                action=action_type,
                message=f"Unknown action: {action_type}",
            )

        except Exception as error:

            return ActionResult(
                success=False,
                action=action_type,
                message=f"Action failed: {error}",
            )
